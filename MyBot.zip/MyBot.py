import hlt
from hlt import NORTH, EAST, SOUTH, WEST, STILL, Move, Square
import random


myID, game_map = hlt.get_init()
hlt.send_init("PythonBot")
dist = {}

def assign_move(square):
    if square.strength < square.production * 5:
        return Move(square, STILL)

    for direction, neighbor in enumerate(game_map.neighbors(square)):
        if square.strength > neighbor.strength and neighbor.owner != myID:
            return Move(square, direction)
#        if neighbor.owner == myID:
#            if dist[neighbor] < dist[square]:
#                return Move(square, direction)
    return Move(square, random.choice((NORTH, SOUTH, EAST, WEST, STILL)))

def setDist():
    for s in game_map:
        if s.owner != myID:
            continue
        if s in dist:
            del dist[s]
        for n in game_map.neighbors(s):
            if n.owner != myID:
                dist[s] = 1
                break
    while not allSet():
        for s in game_map:
            if s.owner != myID:
                continue
            for n in game_map.neighbors(s):
                if n in dist:
                    if s in dist:
                        if dist[s] <= dist[n] + 1:
                            continue
                        else:
                            dist[s] = dist[n] + 1
                    else:
                        dist[s] = dist[n] + 1

def allSet():
    for s in game_map:
        if s.owner == myID and not s in dist:
            return False
    return True
    
while True:
    game_map.get_frame()
#    setDist()
    moves = [assign_move(square) for square in game_map if square.owner == myID]
    hlt.send_frame(moves)
